# PULSEBACK — audio-triggered pre-hit + transient VST3

PULSEBACK is an original drum-layering effect inspired by the general production technique of combining a pre-hit swell/reverse layer with an on-hit transient layer. It is not Cableguys Snapback, does not use Cableguys code, artwork, presets, samples, or trademarks, and is not affiliated with Cableguys.

## Features in this build

- Two independent layers: **PRE-HIT** and **TRANSIENT**.
- Audio transient triggering and MIDI note triggering.
- A fixed 180 ms internal lookahead to make pre-hit playback possible while keeping the dry track aligned through plugin delay compensation.
- Independent layer enable, sample load/clear, reverse playback and polarity invert.
- Per-layer Volume, Pitch, Attack, Decay, Shift, Width, Pan, Dynamics, HP and LP controls.
- Detector Threshold, Sensitivity and Retrigger controls.
- Output gain, dry level and output ceiling/soft limiter.
- Drag-and-drop sample loading, waveform displays and state recall for imported file paths.
- Two original embedded demo samples so the plugin can be auditioned immediately.

Supported sample formats depend on the JUCE basic audio formats enabled by this project. WAV, AIFF and FLAC are the recommended formats.

## JUCE version note

The requested version `JUCE 7.0.20` does not appear in the official JUCE release history. This project pins **JUCE 7.0.14-security**, the latest JUCE 7 security release identified in the upstream release list as of 9 November 2026. Change the `PULSEBACK_JUCE_TAG` CMake cache variable only when intentionally targeting a different JUCE release.

## Build the Windows x64 VST3

### Automatic build with GitHub Actions

1. Create a new GitHub repository for this project (do not place it inside an unrelated project repository).
2. Upload the contents of this folder to the repository root.
3. Open the repository's **Actions** tab and enable workflows if GitHub prompts you.
4. Run **Build Windows VST3** from the workflow list, or push to the `main` branch.
5. Download the artifact named `PULSEBACK-Windows-x64-VST3` from the completed workflow run.
6. Extract the ZIP. Copy `PULSEBACK.vst3` into:
   `C:\Program Files\Common Files\VST3\`
7. Open FL Studio 20 → **Options → Manage plugins** → **Find installed plugins**. If necessary, add the VST3 folder to the plugin search paths.

The workflow is pinned to JUCE 7.0.14-security and builds with the Microsoft Visual C++ toolchain on a Windows x64 runner.

### Build locally on Windows

Requirements: Visual Studio 2022 with the Desktop development with C++ workload, CMake 3.22+, and Git.

```powershell
cmake -S . -B build -A x64 -DPULSEBACK_JUCE_TAG=7.0.14-security
cmake --build build --config Release --target Pulseback_VST3 --parallel
```

The resulting `.vst3` bundle is placed under `build/Pulseback_artefacts/Release/VST3/` (the exact intermediate directory is controlled by CMake/JUCE).

## How to use

1. Insert **PULSEBACK** as an effect on a drum track or bus.
2. Start with **AUDIO TRIGGER**. Set Threshold so only the hits you want cause a trigger. Increase Sensitivity if quiet hits are missed; increase Retrigger if one hit causes multiple triggers.
3. The PRE-HIT layer is scheduled to finish at the detected hit; load a reverse cymbal, noise swell, reversed percussion hit, or vocal texture. The embedded demo layer is a rising-noise whip.
4. The TRANSIENT layer starts at the hit; load a kick, snare, clap, rim or other attack/body sample.
5. Use Shift, Pitch, HP/LP and polarity to fit the layer to the source. Use Width and Pan for stereo placement.
6. Choose **MIDI TRIGGER** to fire the layers from MIDI notes instead of audio detection.

The plugin reports 180 ms latency to the DAW. This is intentional: it provides the lookahead needed for pre-hit playback. FL Studio should compensate for this latency when plugin delay compensation is enabled. This is a production effect, not intended for live playing while monitoring through the plugin.

## Current implementation limits

- The trigger detector is a compact envelope/rising-edge detector, not a machine-learning drum classifier. Very dense or highly dynamic material may need Threshold, Sensitivity and Retrigger adjustment.
- The imported sample file path is saved in the plugin state; the audio file itself is not copied into the DAW project. Keep imported samples in a stable folder or consolidate them with your DAW project.
- Sidechain input, a searchable multi-sample browser, preset management and per-layer solo are not included in this first build.
- The output ceiling is an instantaneous peak clipper/limiter; it is not a lookahead mastering limiter.

## JUCE licensing

JUCE is a separate dependency fetched at build time and is governed by the JUCE 7 EULA and its licence options. JUCE 7 Personal has a stated gross-revenue limit; once that limit is reached, continued distribution requires either an eligible paid JUCE licence or release under GNU GPLv3 with the obligations that entails. Read the [JUCE 7 EULA](https://juce.com/legal/juce-7-license/) before distributing the plugin or using it commercially. This repository does not bundle JUCE source.

## Project layout

- `Source/PluginProcessor.*` — audio engine, trigger detector, voices and state.
- `Source/PluginEditor.*` — dark/purple two-layer interface and sample drag-and-drop.
- `Assets/` — original built-in one-shot WAVs embedded into the plugin.
- `.github/workflows/build-windows-vst3.yml` — Windows x64 VST3 build workflow.
- `CMakeLists.txt` — JUCE 7 CMake project.
