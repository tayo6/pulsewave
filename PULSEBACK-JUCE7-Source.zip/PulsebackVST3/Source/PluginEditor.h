#pragma once

#include "PluginProcessor.h"
#include <functional>

class PulsebackAudioProcessorEditor;

class PulsebackAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                            public juce::FileDragAndDropTarget,
                                            private juce::Timer
{
public:
    explicit PulsebackAudioProcessorEditor(PulsebackAudioProcessor&);
    ~PulsebackAudioProcessorEditor() override = default;

    void paint(juce::Graphics&) override;
    void resized() override;
    bool isInterestedInFileDrag(const juce::StringArray& files) override;
    void filesDropped(const juce::StringArray& files, int x, int y) override;

private:
    class ScopeDisplay final : public juce::Component
    {
    public:
        explicit ScopeDisplay(PulsebackAudioProcessor& p) : processor(p) {}
        void paint(juce::Graphics&) override;
    private:
        PulsebackAudioProcessor& processor;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(ScopeDisplay)
    };

    class WaveformDisplay final : public juce::Component
    {
    public:
        WaveformDisplay(PulsebackAudioProcessor& p, bool isSnap) : processor(p), snapback(isSnap) {}
        void paint(juce::Graphics&) override;
    private:
        PulsebackAudioProcessor& processor;
        bool snapback = false;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WaveformDisplay)
    };

    class LayerPanel final : public juce::Component
    {
    public:
        LayerPanel(PulsebackAudioProcessor&, bool snap, std::function<void(bool)> loadCallback,
                   std::function<void(bool)> clearCallback);
        void paint(juce::Graphics&) override;
        void resized() override;
        void refreshName();
    private:
        PulsebackAudioProcessor& processor;
        bool snapback = false;
        std::function<void(bool)> onLoad;
        std::function<void(bool)> onClear;
        juce::Label title;
        juce::Label sampleName;
        juce::TextButton loadButton { "LOAD SAMPLE" };
        juce::TextButton clearButton { "×" };
        juce::ToggleButton enabledButton { "ON" };
        juce::ToggleButton reverseButton { "REVERSE" };
        juce::ToggleButton phaseButton { "Ø PHASE" };
        WaveformDisplay waveform;
        std::array<std::unique_ptr<juce::Slider>, 10> sliders;
        std::array<std::unique_ptr<juce::Label>, 10> labels;
        std::vector<std::unique_ptr<PulsebackAudioProcessor::APVTS::SliderAttachment>> sliderAttachments;
        std::unique_ptr<PulsebackAudioProcessor::APVTS::ButtonAttachment> enabledAttachment;
        std::unique_ptr<PulsebackAudioProcessor::APVTS::ButtonAttachment> reverseAttachment;
        std::unique_ptr<PulsebackAudioProcessor::APVTS::ButtonAttachment> phaseAttachment;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(LayerPanel)
    };

    void timerCallback() override;
    void openSample(bool snapbackLayer);
    PulsebackAudioProcessor& processor;
    ScopeDisplay scope;
    LayerPanel snapbackPanel;
    LayerPanel transientPanel;
    juce::Label logo;
    juce::Label subtitle;
    juce::Label scopeLabel;
    juce::ComboBox triggerMode;
    std::unique_ptr<PulsebackAudioProcessor::APVTS::ComboBoxAttachment> triggerModeAttachment;
    juce::Slider thresholdSlider, sensitivitySlider, retriggerSlider, drySlider, outputSlider, ceilingSlider;
    juce::Label thresholdLabel, sensitivityLabel, retriggerLabel, dryLabel, outputLabel, ceilingLabel;
    std::unique_ptr<PulsebackAudioProcessor::APVTS::SliderAttachment> thresholdAttachment, sensitivityAttachment,
        retriggerAttachment, dryAttachment, outputAttachment, ceilingAttachment;
    juce::ToggleButton limiterButton { "LIMITER" };
    std::unique_ptr<PulsebackAudioProcessor::APVTS::ButtonAttachment> limiterAttachment;
    std::unique_ptr<juce::FileChooser> fileChooser;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PulsebackAudioProcessorEditor)
};
