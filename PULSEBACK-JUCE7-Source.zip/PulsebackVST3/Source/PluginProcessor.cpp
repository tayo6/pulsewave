#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <BinaryData.h>
#include <limits>

namespace
{
constexpr int fixedLatencyMs = 180;
constexpr float pi = 3.14159265358979323846f;

float dbToGain(float db) noexcept { return std::pow(10.0f, db / 20.0f); }
float clamp01(float value) noexcept { return juce::jlimit(0.0f, 1.0f, value); }
}

PulsebackAudioProcessor::APVTS::ParameterLayout PulsebackAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    auto addFloat = [&p](const juce::String& id, const juce::String& name,
                         juce::NormalisableRange<float> range, float def, const juce::String& unit = {})
    {
        p.push_back(std::make_unique<juce::AudioParameterFloat>(id, name, range, def, unit));
    };
    auto addBool = [&p](const juce::String& id, const juce::String& name, bool def)
    {
        p.push_back(std::make_unique<juce::AudioParameterBool>(id, name, def));
    };

    p.push_back(std::make_unique<juce::AudioParameterChoice>("triggerMode", "Trigger", juce::StringArray { "AUDIO", "MIDI" }, 0));
    addFloat("threshold", "Threshold", { -60.0f, -3.0f, 0.1f }, -28.0f, "dB");
    addFloat("sensitivity", "Sensitivity", { 0.0f, 100.0f, 1.0f }, 65.0f, "%");
    addFloat("retrigger", "Retrigger", { 10.0f, 250.0f, 1.0f }, 70.0f, "ms");
    addFloat("detectorHP", "Detector HP", { 20.0f, 2000.0f, 1.0f, 0.35f }, 35.0f, "Hz");
    addFloat("detectorLP", "Detector LP", { 1000.0f, 20000.0f, 1.0f, 0.35f }, 16000.0f, "Hz");
    addBool("limiter", "Limiter", true);
    addFloat("ceiling", "Ceiling", { -12.0f, 0.0f, 0.1f }, -0.5f, "dB");
    addFloat("output", "Output", { -18.0f, 6.0f, 0.1f }, 0.0f, "dB");
    addFloat("dry", "Dry", { 0.0f, 100.0f, 1.0f }, 100.0f, "%");

    const auto addLayer = [&addFloat, &addBool](const juce::String& prefix, float volume, float width, float decay)
    {
        addBool(prefix + "On", prefix + " On", true);
        addBool(prefix + "Reverse", prefix + " Reverse", false);
        addBool(prefix + "Phase", prefix + " Polarity", false);
        addFloat(prefix + "Volume", prefix + " Volume", { -36.0f, 6.0f, 0.1f }, volume, "dB");
        addFloat(prefix + "Pitch", prefix + " Pitch", { -12.0f, 12.0f, 0.01f }, 0.0f, "st");
        addFloat(prefix + "Attack", prefix + " Attack", { 0.0f, 100.0f, 1.0f }, 0.0f, "%");
        addFloat(prefix + "Decay", prefix + " Decay", { 0.0f, 100.0f, 1.0f }, decay, "%");
        addFloat(prefix + "Shift", prefix + " Shift", { -20.0f, 20.0f, 0.01f }, 0.0f, "ms");
        addFloat(prefix + "Width", prefix + " Width", { 0.0f, 200.0f, 1.0f }, width, "%");
        addFloat(prefix + "Pan", prefix + " Pan", { -100.0f, 100.0f, 1.0f }, 0.0f, "");
        addFloat(prefix + "Dynamics", prefix + " Dynamics", { 0.0f, 100.0f, 1.0f }, 55.0f, "%");
        addFloat(prefix + "HP", prefix + " High-pass", { 20.0f, 12000.0f, 1.0f, 0.35f }, 20.0f, "Hz");
        addFloat(prefix + "LP", prefix + " Low-pass", { 1000.0f, 20000.0f, 1.0f, 0.35f }, 20000.0f, "Hz");
    };
    addLayer("snap", -3.0f, 100.0f, 0.0f);
    addLayer("trans", -1.0f, 120.0f, 45.0f);

    return { p.begin(), p.end() };
}

PulsebackAudioProcessor::PulsebackAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                        .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "PULSEBACK_STATE", createParameterLayout())
{
    for (auto& value : scopeBuffer)
        value.store(0.0f, std::memory_order_relaxed);

    snapbackSample = readSampleMemory(BinaryData::ReverseWhip_wav, static_cast<size_t>(BinaryData::ReverseWhip_wavSize));
    transientSample = readSampleMemory(BinaryData::KickAttack_wav, static_cast<size_t>(BinaryData::KickAttack_wavSize));
}

void PulsebackAudioProcessor::prepareToPlay(double sampleRate, int)
{
    currentSampleRate = juce::jmax(8000.0, sampleRate);
    latencySamples = juce::roundToInt(currentSampleRate * (fixedLatencyMs / 1000.0));
    setLatencySamples(latencySamples);
    const auto ringSize = juce::jmax(2, latencySamples + 1);
    delayLeft.assign(static_cast<size_t>(ringSize), 0.0f);
    delayRight.assign(static_cast<size_t>(ringSize), 0.0f);
    delayWritePosition = 0;
    samplesSinceTrigger = latencySamples;
    detectorEnvelope = detectorPreviousLow = detectorHighOutput = detectorLowOutput = 0.0f;
    detectorGateOpen = false;
    for (auto& v : snapbackVoices) v = Voice {};
    for (auto& v : transientVoices) v = Voice {};
}

void PulsebackAudioProcessor::releaseResources()
{
    delayLeft.clear();
    delayRight.clear();
}

bool PulsebackAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto input = layouts.getMainInputChannelSet();
    const auto output = layouts.getMainOutputChannelSet();
    return (input == juce::AudioChannelSet::mono() || input == juce::AudioChannelSet::stereo()) && input == output;
}

float PulsebackAudioProcessor::getParam(const juce::String& id) const noexcept
{
    if (auto* value = parameters.getRawParameterValue(id))
        return value->load(std::memory_order_relaxed);
    return 0.0f;
}

std::shared_ptr<const PulsebackAudioProcessor::SampleData> PulsebackAudioProcessor::readSampleFile(const juce::File& file) const
{
    if (!file.existsAsFile()) return {};
    juce::AudioFormatManager manager;
    manager.registerBasicFormats();
    std::unique_ptr<juce::AudioFormatReader> reader(manager.createReaderFor(file));
    if (!reader || reader->lengthInSamples <= 0 || reader->lengthInSamples > static_cast<juce::int64>(reader->sampleRate * 30.0))
        return {};

    const int frames = static_cast<int>(reader->lengthInSamples);
    auto sample = std::make_shared<SampleData>();
    sample->sampleRate = reader->sampleRate;
    sample->left.resize(static_cast<size_t>(frames));
    sample->right.resize(static_cast<size_t>(frames));
    juce::AudioBuffer<float> temp(static_cast<int>(reader->numChannels), frames);
    reader->read(&temp, 0, frames, 0, true, true);
    for (int i = 0; i < frames; ++i)
    {
        sample->left[static_cast<size_t>(i)] = temp.getSample(0, i);
        sample->right[static_cast<size_t>(i)] = reader->numChannels > 1 ? temp.getSample(1, i) : temp.getSample(0, i);
    }
    return sample;
}

std::shared_ptr<const PulsebackAudioProcessor::SampleData> PulsebackAudioProcessor::readSampleMemory(const void* bytes, size_t size) const
{
    if (bytes == nullptr || size == 0) return {};
    juce::AudioFormatManager manager;
    manager.registerBasicFormats();
    auto stream = std::make_unique<juce::MemoryInputStream>(bytes, size, false);
    std::unique_ptr<juce::AudioFormatReader> reader(manager.createReaderFor(std::move(stream)));
    if (!reader || reader->lengthInSamples <= 0) return {};

    const int frames = static_cast<int>(reader->lengthInSamples);
    auto sample = std::make_shared<SampleData>();
    sample->sampleRate = reader->sampleRate;
    sample->left.resize(static_cast<size_t>(frames));
    sample->right.resize(static_cast<size_t>(frames));
    juce::AudioBuffer<float> temp(static_cast<int>(reader->numChannels), frames);
    reader->read(&temp, 0, frames, 0, true, true);
    for (int i = 0; i < frames; ++i)
    {
        sample->left[static_cast<size_t>(i)] = temp.getSample(0, i);
        sample->right[static_cast<size_t>(i)] = reader->numChannels > 1 ? temp.getSample(1, i) : temp.getSample(0, i);
    }
    return sample;
}

void PulsebackAudioProcessor::installSample(bool snap, std::shared_ptr<const SampleData> sample,
                                            const juce::String& name, const juce::String& path)
{
    if (snap)
    {
        std::atomic_store_explicit(&snapbackSample, std::move(sample), std::memory_order_release);
        snapbackName = name;
        snapbackPath = path;
    }
    else
    {
        std::atomic_store_explicit(&transientSample, std::move(sample), std::memory_order_release);
        transientName = name;
        transientPath = path;
    }
}

bool PulsebackAudioProcessor::loadSample(bool snap, const juce::File& file)
{
    auto sample = readSampleFile(file);
    if (!sample) return false;
    installSample(snap, std::move(sample), file.getFileNameWithoutExtension(), file.getFullPathName());
    return true;
}

void PulsebackAudioProcessor::clearSample(bool snap)
{
    installSample(snap, {}, "[OFF]", {});
}

std::shared_ptr<const PulsebackAudioProcessor::SampleData> PulsebackAudioProcessor::getSample(bool snap) const
{
    return snap ? std::atomic_load_explicit(&snapbackSample, std::memory_order_acquire)
                : std::atomic_load_explicit(&transientSample, std::memory_order_acquire);
}

juce::String PulsebackAudioProcessor::getSampleName(bool snap) const
{
    return snap ? snapbackName : transientName;
}

float PulsebackAudioProcessor::interpolate(const std::vector<float>& data, double position) noexcept
{
    if (data.empty() || position < 0.0 || position >= static_cast<double>(data.size())) return 0.0f;
    const auto i0 = static_cast<size_t>(position);
    const auto i1 = juce::jmin(i0 + 1, data.size() - 1);
    const float frac = static_cast<float>(position - static_cast<double>(i0));
    return data[i0] + (data[i1] - data[i0]) * frac;
}

void PulsebackAudioProcessor::startVoice(std::array<Voice, 16>& voices,
                                         const std::shared_ptr<const SampleData>& sample,
                                         bool snap, float velocity)
{
    if (!sample || sample->getNumSamples() < 2) return;
    const juce::String prefix = snap ? "snap" : "trans";
    auto* enabled = parameters.getRawParameterValue(prefix + "On");
    if (enabled == nullptr || enabled->load(std::memory_order_relaxed) < 0.5f) return;

    auto* chosen = &voices.front();
    for (auto& voice : voices)
        if (!voice.active) { chosen = &voice; break; }
    if (chosen->active)
        for (auto& voice : voices)
            if (voice.age > chosen->age) chosen = &voice;

    Voice v;
    v.sample = sample;
    v.active = true;
    v.age = 0;
    v.reverse = getParam(prefix + "Reverse") > 0.5f;
    v.polarity = getParam(prefix + "Phase") > 0.5f;
    v.position = v.reverse ? static_cast<double>(sample->getNumSamples() - 1) : 0.0;
    const double pitch = std::pow(2.0, static_cast<double>(getParam(prefix + "Pitch")) / 12.0);
    v.increment = (sample->sampleRate / currentSampleRate) * pitch * (v.reverse ? -1.0 : 1.0);
    v.outputFrames = juce::jmax(1, juce::roundToInt(sample->getNumSamples() / std::abs(v.increment)));
    const int leadFrames = juce::jmax(1, latencySamples - 1);
    if (snap && v.outputFrames > leadFrames)
    {
        const double fitRatio = static_cast<double>(v.outputFrames) / static_cast<double>(leadFrames);
        v.increment *= fitRatio;
        v.outputFrames = leadFrames;
        if (v.reverse) v.position = static_cast<double>(sample->getNumSamples() - 1);
    }
    const int shift = juce::roundToInt(getParam(prefix + "Shift") * 0.001 * currentSampleRate);
    v.delay = snap ? (latencySamples - v.outputFrames + shift) : (latencySamples + shift);
    v.delay = juce::jmax(0, v.delay);
    v.gain = dbToGain(getParam(prefix + "Volume"));
    v.pan = getParam(prefix + "Pan") / 100.0f;
    v.width = getParam(prefix + "Width") / 100.0f;
    v.attack = getParam(prefix + "Attack") / 100.0f;
    v.decay = getParam(prefix + "Decay") / 100.0f;
    v.dynamics = getParam(prefix + "Dynamics") / 100.0f;
    v.velocity = clamp01(velocity);
    v.hpHz = getParam(prefix + "HP");
    v.lpHz = getParam(prefix + "LP");
    *chosen = std::move(v);
}

void PulsebackAudioProcessor::triggerLayers(float velocity)
{
    startVoice(snapbackVoices, std::atomic_load_explicit(&snapbackSample, std::memory_order_acquire), true, velocity);
    startVoice(transientVoices, std::atomic_load_explicit(&transientSample, std::memory_order_acquire), false, velocity);
}

void PulsebackAudioProcessor::renderVoices(std::array<Voice, 16>& voices, float& left, float& right) noexcept
{
    for (auto& v : voices)
    {
        if (!v.active || !v.sample) continue;
        ++v.age;
        if (v.delay > 0)
        {
            --v.delay;
            continue;
        }
        if (v.renderedFrames >= v.outputFrames || v.position < 0.0 || v.position >= v.sample->getNumSamples())
        {
            v.active = false;
            v.sample.reset();
            continue;
        }

        float l = interpolate(v.sample->left, v.position);
        float r = interpolate(v.sample->right, v.position);
        const float hpRc = std::exp(-2.0f * pi * juce::jlimit(20.0f, 12000.0f, v.hpHz) / static_cast<float>(currentSampleRate));
        const float hpL = hpRc * (v.hpOutL + l - v.hpInL);
        const float hpR = hpRc * (v.hpOutR + r - v.hpInR);
        v.hpInL = l; v.hpInR = r; v.hpOutL = hpL; v.hpOutR = hpR;
        l = hpL; r = hpR;
        const float lpAlpha = 1.0f - std::exp(-2.0f * pi * juce::jlimit(1000.0f, 20000.0f, v.lpHz) / static_cast<float>(currentSampleRate));
        v.lpOutL += lpAlpha * (l - v.lpOutL);
        v.lpOutR += lpAlpha * (r - v.lpOutR);
        l = v.lpOutL; r = v.lpOutR;

        const float progress = v.outputFrames > 1 ? static_cast<float>(v.renderedFrames) / static_cast<float>(v.outputFrames - 1) : 1.0f;
        float envelope = 1.0f;
        if (v.attack > 0.0001f && progress < v.attack)
            envelope *= progress / v.attack;
        if (v.decay > 0.0001f && progress > 1.0f - v.decay)
            envelope *= (1.0f - progress) / v.decay;
        const float dynamicGain = (1.0f - v.dynamics) + (v.dynamics * v.velocity);
        const float polarity = v.polarity ? -1.0f : 1.0f;
        const float mid = 0.5f * (l + r);
        const float side = 0.5f * (l - r) * v.width;
        l = mid + side;
        r = mid - side;
        const float panL = v.pan > 0.0f ? (1.0f - v.pan) : 1.0f;
        const float panR = v.pan < 0.0f ? (1.0f + v.pan) : 1.0f;
        const float level = v.gain * envelope * dynamicGain * polarity;
        left += l * level * panL;
        right += r * level * panR;
        v.position += v.increment;
        ++v.renderedFrames;
    }
}

float PulsebackAudioProcessor::applyOutputLimiter(float x) const noexcept
{
    if (getParam("limiter") < 0.5f) return x;
    const float ceiling = dbToGain(getParam("ceiling"));
    return std::copysign(juce::jmin(std::abs(x), ceiling), x);
}

void PulsebackAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = getTotalNumInputChannels();
    const int samples = buffer.getNumSamples();
    if (delayLeft.empty() || delayRight.empty())
    {
        for (int ch = channels; ch < getTotalNumOutputChannels(); ++ch) buffer.clear(ch, 0, samples);
        return;
    }

    const float dryGain = getParam("dry") / 100.0f;
    const bool midiMode = getParam("triggerMode") > 0.5f;
    const float threshold = dbToGain(getParam("threshold"));
    const float sensitivity = getParam("sensitivity") / 100.0f;
    const int retriggerSamples = juce::roundToInt(getParam("retrigger") * 0.001f * static_cast<float>(currentSampleRate));
    const float detectorHP = getParam("detectorHP");
    const float detectorLP = getParam("detectorLP");
    const float detectorHPRC = std::exp(-2.0f * pi * detectorHP / static_cast<float>(currentSampleRate));
    const float detectorLPAlpha = 1.0f - std::exp(-2.0f * pi * detectorLP / static_cast<float>(currentSampleRate));

    juce::MidiBuffer::Iterator midiIterator(midiMessages);
    juce::MidiMessage midiMessage;
    int midiSamplePosition = -1;
    bool hasMidiEvent = midiIterator.getNextEvent(midiMessage, midiSamplePosition);

    for (int i = 0; i < samples; ++i)
    {
        const float inL = channels > 0 ? buffer.getSample(0, i) : 0.0f;
        const float inR = channels > 1 ? buffer.getSample(1, i) : inL;
        const float mono = 0.5f * (inL + inR);

        float detect = mono;
        detectorLowOutput += detectorLPAlpha * (detect - detectorLowOutput);
        const float high = detectorHPRC * (detectorHighOutput + detectorLowOutput - detectorPreviousLow);
        detectorPreviousLow = detectorLowOutput;
        detectorHighOutput = high;
        detect = high;
        const float absDetect = std::abs(detect);
        const float attackCoeff = std::exp(-1.0f / (0.0015f * static_cast<float>(currentSampleRate)));
        const float releaseCoeff = std::exp(-1.0f / (0.075f * static_cast<float>(currentSampleRate)));
        const float envCoeff = absDetect > detectorEnvelope ? attackCoeff : releaseCoeff;
        detectorEnvelope = envCoeff * detectorEnvelope + (1.0f - envCoeff) * absDetect;

        if (samplesSinceTrigger < std::numeric_limits<int>::max()) ++samplesSinceTrigger;
        if (midiMode)
        {
            while (hasMidiEvent && midiSamplePosition <= i)
            {
                if (midiMessage.isNoteOn())
                {
                    const float velocity = midiMessage.getFloatVelocity();
                    triggerLayers(velocity);
                    samplesSinceTrigger = 0;
                }
                hasMidiEvent = midiIterator.getNextEvent(midiMessage, midiSamplePosition);
            }
        }
        else
        {
            const float thresholdWithSensitivity = threshold * (1.35f - 0.75f * sensitivity);
            const bool above = detectorEnvelope >= thresholdWithSensitivity;
            if (above && !detectorGateOpen && samplesSinceTrigger >= retriggerSamples)
            {
                const float normalized = clamp01((detectorEnvelope - thresholdWithSensitivity) / juce::jmax(0.001f, 1.0f - thresholdWithSensitivity));
                const float velocity = clamp01(0.25f + normalized * (0.35f + 0.65f * sensitivity));
                triggerLayers(velocity);
                samplesSinceTrigger = 0;
                detectorGateOpen = true;
            }
            if (!above && detectorEnvelope < thresholdWithSensitivity * 0.55f)
                detectorGateOpen = false;
        }

        const int ringSize = static_cast<int>(delayLeft.size());
        delayLeft[static_cast<size_t>(delayWritePosition)] = inL;
        delayRight[static_cast<size_t>(delayWritePosition)] = inR;
        const int readPosition = (delayWritePosition + 1) % ringSize;
        const float dryL = delayLeft[static_cast<size_t>(readPosition)] * dryGain;
        const float dryR = delayRight[static_cast<size_t>(readPosition)] * dryGain;
        delayWritePosition = readPosition;

        float layerL = 0.0f, layerR = 0.0f;
        renderVoices(snapbackVoices, layerL, layerR);
        renderVoices(transientVoices, layerL, layerR);
        const float outGain = dbToGain(getParam("output"));
        const float outL = applyOutputLimiter((dryL + layerL) * outGain);
        const float outR = applyOutputLimiter((dryR + layerR) * outGain);
        if (channels > 0) buffer.setSample(0, i, outL);
        if (channels > 1) buffer.setSample(1, i, outR);

        const int scopeIndex = scopeWritePosition.fetch_add(1, std::memory_order_relaxed) % scopeSize;
        scopeBuffer[static_cast<size_t>(scopeIndex)].store(juce::jlimit(-1.0f, 1.0f, 0.5f * (inL + inR)), std::memory_order_relaxed);
    }

    for (int ch = channels; ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear(ch, 0, samples);
    midiMessages.clear();
}

void PulsebackAudioProcessor::copyScopeSamples(float* destination, int numSamples) const noexcept
{
    if (destination == nullptr || numSamples <= 0) return;
    const int write = scopeWritePosition.load(std::memory_order_relaxed);
    for (int i = 0; i < numSamples; ++i)
    {
        const int sourceIndex = (write - numSamples + i + scopeSize * 2) % scopeSize;
        destination[i] = scopeBuffer[static_cast<size_t>(sourceIndex)].load(std::memory_order_relaxed);
    }
}

juce::AudioProcessorEditor* PulsebackAudioProcessor::createEditor()
{
    return new PulsebackAudioProcessorEditor(*this);
}

void PulsebackAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    state.setProperty("snapbackPath", snapbackPath, nullptr);
    state.setProperty("transientPath", transientPath, nullptr);
    state.setProperty("snapbackName", snapbackName, nullptr);
    state.setProperty("transientName", transientName, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary(*xml, destData);
}

void PulsebackAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
    {
        auto state = juce::ValueTree::fromXml(*xml);
        if (state.isValid())
        {
            const auto snapPath = state.getProperty("snapbackPath").toString();
            const auto transPath = state.getProperty("transientPath").toString();
            parameters.replaceState(state);
            if (snapPath.isNotEmpty() && juce::File(snapPath).existsAsFile())
                loadSample(true, juce::File(snapPath));
            if (transPath.isNotEmpty() && juce::File(transPath).existsAsFile())
                loadSample(false, juce::File(transPath));
        }
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new PulsebackAudioProcessor();
}
