#include "PluginEditor.h"

namespace
{
const juce::Colour bg          { 0xff101015 };
const juce::Colour panel       { 0xff1b1b23 };
const juce::Colour panelLight  { 0xff24242e };
const juce::Colour purple      { 0xffb58aff };
const juce::Colour blue        { 0xff778aff };
const juce::Colour text        { 0xffeeeaf5 };
const juce::Colour muted       { 0xff92909e };
const juce::Colour line        { 0xff343440 };

void styleSlider(juce::Slider& slider)
{
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 64, 16);
    slider.setColour(juce::Slider::rotarySliderFillColourId, purple);
    slider.setColour(juce::Slider::rotarySliderOutlineColourId, line);
    slider.setColour(juce::Slider::thumbColourId, text);
    slider.setColour(juce::Slider::textBoxTextColourId, text);
    slider.setColour(juce::Slider::textBoxBackgroundColourId, panelLight);
    slider.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
}

void styleButton(juce::Button& button, bool highlighted = false)
{
    button.setColour(juce::TextButton::buttonColourId, highlighted ? juce::Colour(0xff382b4e) : panelLight);
    button.setColour(juce::TextButton::textColourOffId, highlighted ? purple : text);
    button.setColour(juce::TextButton::textColourOnId, text);
    button.setColour(juce::ToggleButton::textColourId, text);
}

juce::Rectangle<float> inset(juce::Rectangle<int> r, float amount)
{
    return r.toFloat().reduced(amount);
}
}

PulsebackAudioProcessorEditor::PulsebackAudioProcessorEditor(PulsebackAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p), scope(p),
      snapbackPanel(p, true, [this](bool s) { openSample(s); }, [this](bool s) { processor.clearSample(s); }),
      transientPanel(p, false, [this](bool s) { openSample(s); }, [this](bool s) { processor.clearSample(s); })
{
    setSize(1180, 820);
    setResizable(true, true);
    setResizeLimits(900, 680, 1600, 1120);

    logo.setText("PULSEBACK", juce::dontSendNotification);
    logo.setFont(juce::Font(30.0f, juce::Font::bold));
    logo.setColour(juce::Label::textColourId, purple);
    logo.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(logo);

    subtitle.setText("PRE-HIT + TRANSIENT LAYER ENGINE", juce::dontSendNotification);
    subtitle.setFont(juce::Font(11.0f, juce::Font::bold));
    subtitle.setColour(juce::Label::textColourId, muted);
    addAndMakeVisible(subtitle);

    scopeLabel.setText("INPUT / LAYER ACTIVITY", juce::dontSendNotification);
    scopeLabel.setFont(juce::Font(10.0f, juce::Font::bold));
    scopeLabel.setColour(juce::Label::textColourId, muted);
    addAndMakeVisible(scopeLabel);
    addAndMakeVisible(scope);
    addAndMakeVisible(snapbackPanel);
    addAndMakeVisible(transientPanel);

    triggerMode.addItem("AUDIO TRIGGER", 1);
    triggerMode.addItem("MIDI TRIGGER", 2);
    triggerMode.setColour(juce::ComboBox::backgroundColourId, panelLight);
    triggerMode.setColour(juce::ComboBox::textColourId, text);
    triggerMode.setColour(juce::ComboBox::outlineColourId, line);
    triggerModeAttachment = std::make_unique<PulsebackAudioProcessor::APVTS::ComboBoxAttachment>(processor.parameters, "triggerMode", triggerMode);
    addAndMakeVisible(triggerMode);

    const auto setupTop = [this](juce::Slider& slider, juce::Label& label, const juce::String& id,
                                 const juce::String& title, std::unique_ptr<PulsebackAudioProcessor::APVTS::SliderAttachment>& attachment)
    {
        styleSlider(slider);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 58, 15);
        label.setText(title, juce::dontSendNotification);
        label.setFont(juce::Font(9.5f, juce::Font::bold));
        label.setColour(juce::Label::textColourId, muted);
        label.setJustificationType(juce::Justification::centred);
        addAndMakeVisible(slider);
        addAndMakeVisible(label);
        attachment = std::make_unique<PulsebackAudioProcessor::APVTS::SliderAttachment>(processor.parameters, id, slider);
    };
    setupTop(thresholdSlider, thresholdLabel, "threshold", "THRESHOLD", thresholdAttachment);
    setupTop(sensitivitySlider, sensitivityLabel, "sensitivity", "SENSITIVITY", sensitivityAttachment);
    setupTop(retriggerSlider, retriggerLabel, "retrigger", "RETRIGGER", retriggerAttachment);
    setupTop(drySlider, dryLabel, "dry", "DRY", dryAttachment);
    setupTop(outputSlider, outputLabel, "output", "OUTPUT", outputAttachment);
    setupTop(ceilingSlider, ceilingLabel, "ceiling", "CEILING", ceilingAttachment);
    limiterAttachment = std::make_unique<PulsebackAudioProcessor::APVTS::ButtonAttachment>(processor.parameters, "limiter", limiterButton);
    styleButton(limiterButton, true);
    addAndMakeVisible(limiterButton);
    startTimerHz(24);
}

void PulsebackAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bg);
    g.setColour(panel);
    g.fillRoundedRectangle(18.0f, 12.0f, static_cast<float>(getWidth() - 36), 58.0f, 12.0f);
    g.setColour(panelLight);
    g.fillRoundedRectangle(inset(scope.getBounds(), 0.0f), 10.0f);
    g.setColour(line);
    g.drawRoundedRectangle(inset(scope.getBounds(), 0.0f), 10.0f, 1.0f);
    g.setColour(panel);
    g.drawLine(static_cast<float>(getWidth() / 2), 350.0f, static_cast<float>(getWidth() / 2), static_cast<float>(getHeight() - 18), 1.0f);
    g.setColour(muted);
    g.setFont(10.0f);
    g.drawText("LOOKAHEAD  " + juce::String("180") + " ms",
               24, getHeight() - 20, 170, 14, juce::Justification::left);
    g.drawText("DRAG A WAV / AIFF / FLAC FILE ONTO EITHER LAYER TO LOAD IT",
               230, getHeight() - 20, getWidth() - 460, 14, juce::Justification::centred);
}

void PulsebackAudioProcessorEditor::resized()
{
    const int w = getWidth();
    const int margin = 18;
    logo.setBounds(40, 18, 250, 38);
    subtitle.setBounds(290, 27, 250, 22);
    scopeLabel.setBounds(34, 76, 220, 18);
    scope.setBounds(margin, 98, w - margin * 2, 218);

    const int barY = 326;
    triggerMode.setBounds(28, barY + 24, 145, 30);
    const int sliderW = 95;
    const int startX = 188;
    const int gap = 8;
    auto place = [&](juce::Slider& s, juce::Label& l, int index)
    {
        const int x = startX + index * (sliderW + gap);
        l.setBounds(x, barY + 2, sliderW, 15);
        s.setBounds(x + 5, barY + 15, sliderW - 10, 64);
    };
    place(thresholdSlider, thresholdLabel, 0);
    place(sensitivitySlider, sensitivityLabel, 1);
    place(retriggerSlider, retriggerLabel, 2);
    place(drySlider, dryLabel, 3);
    place(outputSlider, outputLabel, 4);
    place(ceilingSlider, ceilingLabel, 5);
    limiterButton.setBounds(startX + 6 * (sliderW + gap), barY + 28, 110, 32);

    const int panelsY = 414;
    const int panelGap = 12;
    const int panelW = (w - margin * 2 - panelGap) / 2;
    snapbackPanel.setBounds(margin, panelsY, panelW, getHeight() - panelsY - 42);
    transientPanel.setBounds(margin + panelW + panelGap, panelsY, panelW, getHeight() - panelsY - 42);
}

bool PulsebackAudioProcessorEditor::isInterestedInFileDrag(const juce::StringArray& files)
{
    if (files.isEmpty()) return false;
    const auto extension = juce::File(files[0]).getFileExtension().toLowerCase();
    return extension == ".wav" || extension == ".aif" || extension == ".aiff" || extension == ".flac" || extension == ".ogg";
}

void PulsebackAudioProcessorEditor::filesDropped(const juce::StringArray& files, int x, int y)
{
    if (files.isEmpty() || y < 390) return;
    const bool snap = x < getWidth() / 2;
    const juce::File file(files[0]);
    if (!processor.loadSample(snap, file))
        juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon, "PULSEBACK",
            "Could not read this audio file. Try WAV, AIFF or FLAC.");
    snapbackPanel.refreshName();
    transientPanel.refreshName();
}

void PulsebackAudioProcessorEditor::timerCallback()
{
    scope.repaint();
    snapbackPanel.repaint();
    transientPanel.repaint();
    snapbackPanel.refreshName();
    transientPanel.refreshName();
}

void PulsebackAudioProcessorEditor::openSample(bool snap)
{
    fileChooser = std::make_unique<juce::FileChooser>(snap ? "Load Snapback Sample" : "Load Transient Sample",
        juce::File::getSpecialLocation(juce::File::userHomeDirectory), "*.wav;*.aif;*.aiff;*.flac;*.ogg");
    fileChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this, snap](const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (file.existsAsFile() && !processor.loadSample(snap, file))
                juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon, "PULSEBACK",
                    "Could not read this audio file. Try WAV, AIFF or FLAC.");
            snapbackPanel.refreshName();
            transientPanel.refreshName();
        });
}

void PulsebackAudioProcessorEditor::ScopeDisplay::paint(juce::Graphics& g)
{
    auto area = getLocalBounds().toFloat().reduced(12.0f);
    const float midY = area.getCentreY();
    g.setColour(line.withAlpha(0.7f));
    for (int i = 1; i < 8; ++i)
        g.drawVerticalLine(static_cast<int>(area.getX() + area.getWidth() * i / 8.0f), area.getY(), area.getBottom());
    g.drawHorizontalLine(static_cast<int>(midY), area.getX(), area.getRight());

    constexpr int count = 768;
    std::array<float, count> values {};
    processor.copyScopeSamples(values.data(), count);
    juce::Path wave;
    for (int i = 0; i < count; ++i)
    {
        const float x = area.getX() + area.getWidth() * static_cast<float>(i) / static_cast<float>(count - 1);
        const float y = midY - values[static_cast<size_t>(i)] * area.getHeight() * 0.43f;
        if (i == 0) wave.startNewSubPath(x, y); else wave.lineTo(x, y);
    }
    g.setColour(blue.withAlpha(0.95f));
    g.strokePath(wave, juce::PathStrokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour(purple.withAlpha(0.18f));
    auto glow = wave;
    g.strokePath(glow, juce::PathStrokeType(7.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour(text.withAlpha(0.35f));
    g.setFont(10.0f);
    g.drawText("IN", 12, 8, 26, 14, juce::Justification::left);
    g.setColour(purple);
    g.drawText("PRE-HIT  /  TRANSIENT", 40, 8, 200, 14, juce::Justification::left);
}

void PulsebackAudioProcessorEditor::WaveformDisplay::paint(juce::Graphics& g)
{
    auto area = getLocalBounds().toFloat().reduced(7.0f, 6.0f);
    g.setColour(juce::Colour(0xff121219));
    g.fillRoundedRectangle(area, 7.0f);
    g.setColour(line);
    g.drawHorizontalLine(static_cast<int>(area.getCentreY()), area.getX(), area.getRight());

    const auto data = processor.getSample(snapback);
    if (!data || data->left.size() < 2)
    {
        g.setColour(muted);
        g.setFont(11.0f);
        g.drawText("DROP AUDIO HERE  /  CLICK LOAD SAMPLE", area.toNearestInt(), juce::Justification::centred);
        return;
    }

    const auto& samples = data->left;
    const int width = juce::jmax(1, static_cast<int>(area.getWidth()));
    juce::Path top, bottom;
    for (int x = 0; x < width; ++x)
    {
        const size_t start = static_cast<size_t>((static_cast<double>(x) / width) * samples.size());
        const size_t end = juce::jmin(samples.size(), static_cast<size_t>((static_cast<double>(x + 1) / width) * samples.size()));
        float peak = 0.0f;
        for (size_t i = start; i < juce::jmax(start + 1, end); ++i)
            peak = juce::jmax(peak, std::abs(samples[juce::jmin(i, samples.size() - 1)]));
        const float xPos = area.getX() + static_cast<float>(x);
        const float amp = peak * area.getHeight() * 0.43f;
        const float cy = area.getCentreY();
        if (x == 0) { top.startNewSubPath(xPos, cy - amp); bottom.startNewSubPath(xPos, cy + amp); }
        else { top.lineTo(xPos, cy - amp); bottom.lineTo(xPos, cy + amp); }
    }
    const auto colour = snapback ? blue : purple;
    g.setColour(colour.withAlpha(0.20f));
    g.strokePath(top, juce::PathStrokeType(5.0f));
    g.strokePath(bottom, juce::PathStrokeType(5.0f));
    g.setColour(colour);
    g.strokePath(top, juce::PathStrokeType(1.4f));
    g.strokePath(bottom, juce::PathStrokeType(1.4f));
}

PulsebackAudioProcessorEditor::LayerPanel::LayerPanel(PulsebackAudioProcessor& p, bool snap,
    std::function<void(bool)> loadCallback, std::function<void(bool)> clearCallback)
    : processor(p), snapback(snap), onLoad(std::move(loadCallback)), onClear(std::move(clearCallback)), waveform(p, snap)
{
    title.setText(snap ? "01  /  PRE-HIT" : "02  /  TRANSIENT", juce::dontSendNotification);
    title.setFont(juce::Font(15.0f, juce::Font::bold));
    title.setColour(juce::Label::textColourId, snap ? blue : purple);
    addAndMakeVisible(title);

    sampleName.setFont(juce::Font(10.5f));
    sampleName.setColour(juce::Label::textColourId, text);
    sampleName.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(sampleName);
    refreshName();

    styleButton(loadButton, true);
    styleButton(clearButton);
    styleButton(enabledButton, true);
    styleButton(reverseButton);
    styleButton(phaseButton);
    addAndMakeVisible(loadButton); addAndMakeVisible(clearButton); addAndMakeVisible(enabledButton);
    addAndMakeVisible(reverseButton); addAndMakeVisible(phaseButton); addAndMakeVisible(waveform);
    loadButton.onClick = [this] { if (onLoad) onLoad(snapback); };
    clearButton.onClick = [this] { if (onClear) onClear(snapback); refreshName(); };

    const juce::String prefix = snap ? "snap" : "trans";
    enabledAttachment = std::make_unique<PulsebackAudioProcessor::APVTS::ButtonAttachment>(processor.parameters, prefix + "On", enabledButton);
    reverseAttachment = std::make_unique<PulsebackAudioProcessor::APVTS::ButtonAttachment>(processor.parameters, prefix + "Reverse", reverseButton);
    phaseAttachment = std::make_unique<PulsebackAudioProcessor::APVTS::ButtonAttachment>(processor.parameters, prefix + "Phase", phaseButton);

    const std::array<juce::String, 10> ids { prefix + "Volume", prefix + "Pitch", prefix + "Attack", prefix + "Decay", prefix + "Shift",
        prefix + "Width", prefix + "Pan", prefix + "Dynamics", prefix + "HP", prefix + "LP" };
    const std::array<juce::String, 10> names { "VOLUME", "PITCH", "ATTACK", "DECAY", "SHIFT", "WIDTH", "PAN", "DYNAMICS", "HP", "LP" };
    for (size_t i = 0; i < sliders.size(); ++i)
    {
        sliders[i] = std::make_unique<juce::Slider>();
        labels[i] = std::make_unique<juce::Label>();
        styleSlider(*sliders[i]);
        sliders[i]->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 55, 14);
        labels[i]->setText(names[i], juce::dontSendNotification);
        labels[i]->setFont(juce::Font(8.5f, juce::Font::bold));
        labels[i]->setColour(juce::Label::textColourId, muted);
        labels[i]->setJustificationType(juce::Justification::centred);
        addAndMakeVisible(*sliders[i]); addAndMakeVisible(*labels[i]);
        sliderAttachments.push_back(std::make_unique<PulsebackAudioProcessor::APVTS::SliderAttachment>(processor.parameters, ids[i], *sliders[i]));
    }
}

void PulsebackAudioProcessorEditor::LayerPanel::refreshName()
{
    sampleName.setText(processor.getSampleName(snapback), juce::dontSendNotification);
}

void PulsebackAudioProcessorEditor::LayerPanel::paint(juce::Graphics& g)
{
    g.setColour(panel);
    g.fillRoundedRectangle(getLocalBounds().toFloat(), 12.0f);
    g.setColour(line);
    g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(0.5f), 12.0f, 1.0f);
    g.setColour(snapback ? blue.withAlpha(0.12f) : purple.withAlpha(0.12f));
    g.fillRoundedRectangle(12.0f, 10.0f, 4.0f, 28.0f, 2.0f);
}

void PulsebackAudioProcessorEditor::LayerPanel::resized()
{
    auto area = getLocalBounds().reduced(15, 12);
    title.setBounds(area.removeFromTop(30).withWidth(160));
    enabledButton.setBounds(getWidth() - 92, 13, 72, 24);
    loadButton.setBounds(getWidth() - 205, 48, 132, 25);
    clearButton.setBounds(getWidth() - 66, 48, 42, 25);
    reverseButton.setBounds(18, 48, 88, 25);
    phaseButton.setBounds(112, 48, 88, 25);
    sampleName.setBounds(210, 48, juce::jmax(50, getWidth() - 430), 25);
    waveform.setBounds(13, 79, getWidth() - 26, 88);

    const int top = 174;
    const int bottom = getHeight() - 8;
    const int rowH = (bottom - top) / 2;
    const int colW = (getWidth() - 28) / 5;
    for (int i = 0; i < 10; ++i)
    {
        const int row = i / 5;
        const int col = i % 5;
        const int x = 14 + col * colW;
        const int y = top + row * rowH;
        labels[static_cast<size_t>(i)]->setBounds(x, y, colW, 15);
        sliders[static_cast<size_t>(i)]->setBounds(x + 2, y + 12, colW - 4, rowH - 12);
    }
}

