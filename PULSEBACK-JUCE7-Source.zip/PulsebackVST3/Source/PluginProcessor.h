#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <memory>
#include <vector>

class PulsebackAudioProcessor final : public juce::AudioProcessor
{
public:
    using APVTS = juce::AudioProcessorValueTreeState;

    struct SampleData
    {
        double sampleRate = 44100.0;
        std::vector<float> left;
        std::vector<float> right;
        int getNumSamples() const noexcept { return static_cast<int>(left.size()); }
    };

    PulsebackAudioProcessor();
    ~PulsebackAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 5.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    APVTS parameters;

    bool loadSample(bool snapbackLayer, const juce::File& file);
    void clearSample(bool snapbackLayer);
    std::shared_ptr<const SampleData> getSample(bool snapbackLayer) const;
    juce::String getSampleName(bool snapbackLayer) const;
    void copyScopeSamples(float* destination, int numSamples) const noexcept;
    int getLatencySamplesForDisplay() const noexcept { return latencySamples; }

private:
    struct Voice
    {
        std::shared_ptr<const SampleData> sample;
        double position = 0.0;
        double increment = 1.0;
        int delay = 0;
        int age = 0;
        bool active = false;
        bool reverse = false;
        bool polarity = false;
        float gain = 1.0f;
        float pan = 0.0f;
        float width = 1.0f;
        float attack = 0.0f;
        float decay = 0.7f;
        float dynamics = 0.0f;
        float velocity = 1.0f;
        float hpHz = 20.0f;
        float lpHz = 20000.0f;
        float hpInL = 0.0f, hpInR = 0.0f;
        float hpOutL = 0.0f, hpOutR = 0.0f;
        float lpOutL = 0.0f, lpOutR = 0.0f;
        int outputFrames = 0;
        int renderedFrames = 0;
    };

    static APVTS::ParameterLayout createParameterLayout();
    float getParam(const juce::String& id) const noexcept;
    std::shared_ptr<const SampleData> readSampleFile(const juce::File& file) const;
    std::shared_ptr<const SampleData> readSampleMemory(const void* bytes, size_t size) const;
    void installSample(bool snapbackLayer, std::shared_ptr<const SampleData> sample, const juce::String& name, const juce::String& path);
    void triggerLayers(float velocity);
    void startVoice(std::array<Voice, 16>& voices,
                    const std::shared_ptr<const SampleData>& sample,
                    bool snapbackLayer, float velocity);
    void renderVoices(std::array<Voice, 16>& voices, float& left, float& right) noexcept;
    static float interpolate(const std::vector<float>& data, double position) noexcept;
    float applyOutputLimiter(float sample) const noexcept;

    std::shared_ptr<const SampleData> snapbackSample;
    std::shared_ptr<const SampleData> transientSample;
    juce::String snapbackName { "Built-in Reverse Whip" };
    juce::String transientName { "Built-in Kick Attack" };
    juce::String snapbackPath;
    juce::String transientPath;

    std::array<Voice, 16> snapbackVoices {};
    std::array<Voice, 16> transientVoices {};
    std::vector<float> delayLeft, delayRight;
    int delayWritePosition = 0;
    int latencySamples = 0;
    double currentSampleRate = 44100.0;
    int samplesSinceTrigger = 0;
    float detectorEnvelope = 0.0f;
    float detectorPreviousLow = 0.0f;
    float detectorHighInput = 0.0f;
    float detectorHighOutput = 0.0f;
    float detectorLowOutput = 0.0f;
    bool detectorGateOpen = false;

    static constexpr int scopeSize = 2048;
    std::array<std::atomic<float>, scopeSize> scopeBuffer {};
    std::atomic<int> scopeWritePosition { 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PulsebackAudioProcessor)
};
